# CQR10 cluster source bundle

Extract this ZIP into a new source directory and run commands from its root.
It contains code and frozen settings only: no results, fitted models, data
archives, timing pilots, compiler/runtime installation or cleanup history.

Use a supported Python environment (the local validation used Python 3.12):

```bash
python -m pip install -r envelope_method/cqr10/requirements.txt
python envelope_method/cqr10/runner.py --storage compact --out /scratch/YOUR_NAME/cqr10
```

The second command is a dry run: expect 22 configurations and 1,430 trials.
To run, replace the scratch path and worker count with your allocated resources:

```bash
python envelope_method/cqr10/runner.py --run --storage compact --out /scratch/YOUR_NAME/cqr10 --workers 1
```

This is the application command, not a scheduler submission script. Use your
cluster's normal allocation/submission procedure. No upload or submission has
been performed. Keep the source directory unchanged during a study, use the same
environment when resuming, and avoid overlapping jobs writing the same settings.

Compact saves every trial's metrics, coordinates, diagnostics, seeds, provenance
and checksums, plus CSV summaries. It writes no NPZ or joblib files. `--storage
scores` additionally saves scores/base widths/method bounds; `--storage full`
also saves raw observations and fitted models. Storage does not change trial
IDs, seeds, fitting or peak working memory. Richer retention after a compact run
requires a separate output directory and refitting; no silent upgrades occur.

The notebook at `envelope_method/cqr10/cqr10_experiments.ipynb` is the current
manual notebook with two optional timing-pilot preview cells guarded because
this bundle omits pilot data. Its run switch remains OFF. Numerical experiment,
summary and plotting code is unchanged. `RUNTIME_ESTIMATES.md` records the local
planning estimates; it does not establish cluster timing or parallel speedup.

`SOURCE_MANIFEST.json` records every payload member's SHA-256 and origin. All
scientific Python source is copied byte-for-byte. The notebook derivation is
identified separately with both the original and packaged hashes. The shared
experiment module includes optional non-CQR branches whose datasets/generators
are outside this CQR-only bundle; the documented CQR10 entry point is complete.
